require('./imagetools/plugin.js');
require('./importword/plugin.min.js');
require('./indent2em/plugin.js');
require('./layout/plugin.min.js');
require('./letterspacing/plugin.js');
require('./lineheight/plugin.min.js');
require('./table/plugin.min.js');
require('./upfile/plugin.min.js');
require('./bdmap/plugin.min.js');
require('./axupimgs/plugin.min.js');
require('./attachment/plugin.min.js');
require('./slashHeader/plugin.js');
require('./formatpainter/plugin.min.js');
require('./checklist/plugin.min.js');


